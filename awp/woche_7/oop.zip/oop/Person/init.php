<?php

    use Person\BL\Person;


    function autoloader($classname) {
        $lastSlash = strpos($classname, '\\')+1;
        $classname = substr($classname, $lastSlash);
        $directory = str_replace('\\', '/', $classname);
        $filename = __DIR__ .'/Person/' . $directory . '.php';
        require_once($filename);
      }

      spl_autoload_register('autoloader');

      $ste = new Person();
      $alter = $ste->setAlter(23);
      echo $alter;

      var_dump($ste);