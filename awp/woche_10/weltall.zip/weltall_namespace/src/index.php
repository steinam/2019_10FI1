<?php

use logic\location\Stadt;
use logic\liveform\Mensch;
use logic\vehicle\Raumschiff;
use logic\alliance\MenschenVerband;

function meinAutoloader($class)
{
    $split = explode('\\', $class);
    $classPath = implode('/', $split);
    $path = "$classPath.php";

    $filename = __DIR__ . '/'.  $path;
    include_once $filename;
}

spl_autoload_register('meinAutoloader');

$wue = new Stadt("Würzburg");
var_dump($wue);

$steinam = new Mensch($wue, "steinam", 55, 100);
var_dump($steinam);

$wue->setLebewesen($steinam);
$wue->setLebewesen($steinam);


var_dump($steinam);

var_dump($wue->getInfos());

$enterprise = new Raumschiff("USS Enterprise", 100000);
var_dump($enterprise);

$Sternenfoederation = new MenschenVerband("StarFederation");

$enterprise->setVerband($Sternenfoederation);

var_dump($enterprise);

