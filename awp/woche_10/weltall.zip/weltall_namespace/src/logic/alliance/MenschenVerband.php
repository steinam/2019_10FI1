<?php

namespace logic\alliance;

class MenschenVerband extends Verband{


    function __construct(string $n){

        parent::__construct($n);

    }
}
