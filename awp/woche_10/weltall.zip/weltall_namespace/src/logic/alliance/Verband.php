<?php

namespace logic\alliance;


abstract class Verband
{

    protected $Name;

    function __construct(string $n){

        $this->Name = $n;

    }

}