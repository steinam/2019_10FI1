<?php

namespace location;

use logic\location\Ort;

class Planet extends Ort{



}