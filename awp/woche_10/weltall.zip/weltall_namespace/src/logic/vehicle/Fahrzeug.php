<?php

namespace logic\vehicle;

use logic\alliance\Verband;

abstract class Fahrzeug{

    protected $Bezeichnung;
    protected $Geschwindigkeit;

    protected $Verband;


    function __construct(string $b, int $v )
    {
        $this->Bezeichnung = $b;
        $this->Geschwindigkeit = $v;

    }

    function setVerband(Verband $v){

        $this->Verband = $v;

    }

}