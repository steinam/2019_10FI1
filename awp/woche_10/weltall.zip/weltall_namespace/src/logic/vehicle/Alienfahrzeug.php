<?php

namespace logic\vehicle;


//hier darüber sprechen, wie man Mehrfachvererbung realisieren könnte
class Alienfahrzeug extends Fahrzeug
{



}