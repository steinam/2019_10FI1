<?php

namespace logic\vehicle;

class Raumschiff extends Fahrzeug
{

    public function move()
    {

            function __construct(string $b, int $v)
            {
                parent::__construct($b, $v);
            }

    }

}