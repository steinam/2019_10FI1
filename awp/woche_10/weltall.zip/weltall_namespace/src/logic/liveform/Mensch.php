<?php
/**
 * Created by PhpStorm.
 * User: kstei
 * Date: 18.05.2019
 * Time: 08:56
 */

namespace logic\liveform;

//use logic\liveform\Lebewesen;
use logic\location\Ort;



class Mensch extends Lebewesen
{
    /**
     * Mensch constructor.
     * @param Stadt $town
     */
    function __construct(Ort $town, string $n, int $a, int $le )
    {
        parent::__construct($n, $a, $le);
        $this->loc = $town;

    }
}