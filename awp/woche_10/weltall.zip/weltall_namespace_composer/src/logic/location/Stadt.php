<?php

namespace logic\location;
use logic\location\Ort;

class Stadt extends Ort{

    function __construct(string $name)
    {
        $this->Name = $name;
    }

}