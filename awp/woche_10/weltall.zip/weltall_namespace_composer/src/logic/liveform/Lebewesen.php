<?php
/**
 * Created by PhpStorm.
 * User: kstei
 * Date: 18.05.2019
 * Time: 08:56
 */
namespace logic\liveform;


/**
 * Class Lebewesen
 *
 * The moter of all liveforms
 *
 * @package logic\liveform
 *
 *
 */
abstract class Lebewesen{

    protected $loc;

    protected $Name;
    protected $Groesse;
    protected $Alter;
    protected $live_energy;

    function __construct(string $n, int $a, int $le)
    {
            $this->Name = $n;
            $this->Alter = $a;
            $this->live_energy = $le;
    }
}