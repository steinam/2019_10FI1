<?php

require "vendor/autoload.php";

//see: https://phpenthusiast.com/blog/how-to-autoload-with-composer

/*
 * composer require monolog/monolog
 *
 * in composer.json eigene Namespaces einbinden
 *
 * {
    "require": {
        "monolog/monolog": "^1.24"
    },
    "autoload": {"psr-4":{"logic\\":"src/"}}
}
 * composer update
 * composer dumpautoload -o
 *
 */

use logic\location\Stadt;
use logic\liveform\Mensch;


use Twig\Error\LoaderError;


$test = new LoaderError()



function meinAutoloader($class)
{
    $split = explode('\\', $class);
    $classPath = implode('/', $split);
    $path = "$classPath.php";

    $filename = __DIR__ . '/'.  $path;
    include_once $filename;
}

//spl_autoload_register('meinAutoloader');

$wue = new Stadt("Würzburg");
var_dump($wue);

$steinam = new Mensch($wue, "steinam", 55, 100);
var_dump($steinam);

$wue->setLebewesen($steinam);
$wue->setLebewesen($steinam);

var_dump($steinam);

var_dump($wue->getInfos());

