<?php
/**
 * Created by PhpStorm.
 * User: kstei
 * Date: 18.05.2019
 * Time: 13:03
 */

namespace weltall\view;

    class democlass{
        public $test = 33333;
    }
