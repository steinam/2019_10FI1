<?php
/**
 * Created by PhpStorm.
 * User: kstei
 * Date: 18.05.2019
 * Time: 08:56
 */

namespace weltall\logic\liveform;

//use logic\liveform\Lebewesen;
use weltall\logic\location\Ort;
use weltall\view\democlass;



class Mensch extends Lebewesen
{
    /**
     * Mensch constructor.
     * @param Stadt $town
     */
    function __construct(Ort $town, string $n, int $a, int $le )
    {
        parent::__construct($n, $a, $le);
        $this->loc = $town;

    }


    function printdemo(): int{

        $test = new democlass();
        return $test->test;


}
}