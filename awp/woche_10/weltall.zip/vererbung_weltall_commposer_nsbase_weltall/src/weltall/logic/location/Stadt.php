<?php

namespace weltall\logic\location;
use weltall\logic\location\Ort;

class Stadt extends Ort{

    function __construct(string $name)
    {
        $this->Name = $name;
    }

}