<?php

namespace weltall\logic\location;

use weltall\logic\liveform\Lebewesen;

/**
 * "Die Mutter aller Orte"
 *
 * @author STE <steinam@habmichlieb.com>;
 * @package location\ort;
 * @license MIT
 * @category Was muss da stehen
 */
abstract class Ort
{

    protected $Name;
    protected $Lebewesen = array();


    function getInfos(): int
    {
        return count($this->Lebewesen);
    }

    function setLebewesen(Lebewesen $lv)
    {
        array_push($this->Lebewesen, $lv);
    }
}