<?php

namespace weltall\logic\location;

use weltall\logic\location\Ort;

class Planet extends Ort{



}