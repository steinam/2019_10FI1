<?php

    namespace Fahrtenbuch\BL;

    interface Kosten{

        public function getPreis() : float;

    }