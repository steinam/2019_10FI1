<?php

namespace Fahrtenbuch\BL;

class Fahrer{

    private $Name;

    public function __construct(string $n)
    {
        $this->Name = $n;

    }

}